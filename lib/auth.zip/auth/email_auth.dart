// import 'package:MOAONLINE/globals/firebase_variables.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';

// import 'auth_util.dart';

// Future<Future<User?>> signInWithEmail(
//     BuildContext context, String email, String password) async {
//   final signInFunc = () =>
//       auth.signInWithEmailAndPassword(email: email.trim(), password: password);
//   return signInOrCreateAccount(context, signInFunc);
// }

// Future<Future<User?>> createAccountWithEmail(
//     BuildContext context, String email, String password) async {
//   final createAccountFunc = () => auth.createUserWithEmailAndPassword(
//       email: email.trim(), password: password);
//   return signInOrCreateAccount(context, createAccountFunc);
// }
